package args;

public class ParserArgsException extends RuntimeException {
    public ParserArgsException(String message) {
        super(message);
    }
}

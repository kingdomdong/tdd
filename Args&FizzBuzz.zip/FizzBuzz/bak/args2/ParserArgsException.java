package args;

public class ParserArgsException extends RuntimeException {
    public ParserArgsException(String msg) {
        super(msg);
    }
}
